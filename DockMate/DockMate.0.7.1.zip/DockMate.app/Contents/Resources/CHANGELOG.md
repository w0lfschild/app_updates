### Todo

-   Display windows for Screen-recording and Automation explaining the reasoning to the userbefore the system prompts
-   Fix preview hiding in fullscreen after mouse moves off dock

### 0.7.1

-   Privews are now displayed almost instantaneously (0.1 or less seconds even for large numbers of windows 20+)
-   Better handling of large number of windows
-   Sort preview windows by Desktop # then Window Title
-   Fix preview window flickering (redrawing) when moving mouse up from or down to a dock icon
-   Fix music view missalignment in window
-   Fix music view not updating if track rolls over while view is showing
-   Fix electron apps showing blank window if app is minimized 
    -   Instead shows last known image
    -   Image will still be blank if the window has not been unhidden since DockMate launched
-   Fix large preview window not hiding when last window of an app is closed
-   Fix windows potentially reporting the wrong space
-   Fix crash when web tab reported no title
-   Removed tab management from web views

### 0.6.1

-   Major code refactoring
-   Massive speed up of preview display time
-   Fixed memory leaks
-   Fix crash if music app was closed while displaying view
-   Chrome and Safari previews now show a tab selector

### 0.5.1

-   Fix memory leak
-   Fix tiles displaying off screen
-   Smaller minimum tile size

### 0.4.22

-    Progress bar works for iTunes, Spotify, Music apps
-    Track progress updates over time
-    Tiles showing when they shouldn't
-    Podcasts view progress-bar skip to point when clicked / dragged
-    Podcasts view progress-bar show progress while playing
-    Music views scrolling title and artist text
-    Setup Appcenter
-    Setup Paddle
-    Setup Sparkle
-    Setup LetsMove
-    Make about window
-    Space transitions
-    Fade in window
-    Window drawing over dock
-    Preview preference settings
-    Dock icon focus time before showing preview
-    Hover on preview to show floating "On-screen" preview
-    Finish General Preferences
-    Watch for dock restarts
-    Bug fixes
