### Resources

- Privileged scripts : [STPrivilegedTask](https://www.github.com/sveinbjornt/STPrivilegedTask)
- Code Injection : [mach_inject](https://github.com/rentzsch/mach_inject)
- Trash Badge : [Parasite](https://github.com/ParasiteTeam/extensions)
- Stock Themes : [Wandmalfarbe Themes](https://github.com/Wandmalfarbe/cDock-Themes)
- Stock Themes : [DeviantArt](https://blackvariant.deviantart.com/)
- Sales & Licenses : [Paddle](https://paddle.com/)
- Launch at login : [StartAtLoginController](https://github.com/alexzielenski/StartAtLoginController)
- Method Swizzling : [ZKSwizzle](https://github.com/alexzielenski/ZKSwizzle)
- Dock code : [Dockify](https://github.com/alexzielenski/dockify)
- Dock code : [Dark Dock](https://github.com/b3ll/DarkDock)
- Dock code : [Modck](https://github.com/mstg/Modck)
- Dock code : [mDock](https://github.com/over-powdered/mDock)
- Mission control auto expand : [forceFullDesktopBar](https://github.com/briankendall/forceFullDesktopBar)
- Analytics : [appcenter-sdk-apple](https://www.github.com/microsoft/appcenter-sdk-apple)
- Updates : [Sparkle](https://www.github.com/sparkle-project/Sparkle)
- Auto move : [LetsMove](https://www.github.com/potionfactory/LetsMove)
- Object Hooking : [JSRollCall](https://github.com/jslegendre/JSRollCall)

### Lead Developers

- [Wolfgang Baird](https://github.com/w0lfschild) ([w0lfschild](https://github.com/w0lfschild)) ([MacEnhance](https://www.macenhance.com/))
- [jslegendre](https://github.com/jslegendre) ([Todeska](https://www.todeska.app/))

### Contributors

- [jsteweii](https://www.deviantart.com/jsteweii) [Mavericks theme](https://www.deviantart.com/jsteweii/art/Mavericks-783845879)
