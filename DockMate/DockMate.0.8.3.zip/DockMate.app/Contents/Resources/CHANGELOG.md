### 0.8.3

- Fix not showing in screen recording privacy tab automatically
- Now automatically restarts self after getting privacy permissions
- Fix Calendar view showing as blank if the user didn't click the system prompt to grant permission

### 0.8.2

- Native M1 support
- New mouse over view for Calendar (and Fantastical)
- Join Zoom and Google Meets calendar events with one click
- New informative UI for accessibility permissions
- New support for showing previews for closed apps
- Now show previews for music / calendar even when closed
- Now Dock autohide setting is copied from the Dock settings
- Faster dock mouse-over previews
- Fix preview overlapping the Dock in left orientation
- Fix for preview not properly aligning in screen bounds
- Fix full size preview not showing correctly
- Fix newly created windows being sent to a nonexistent display
- Fix Finder preview showing blank window with TotalFinder
- Fix music preview when playing Apple Music
- Fix music preview scrolling title/album
- Fix issue with music item causing excessive memory usage
- Fix issue with music item causing excessive cpu usage
- Music preview shows control center info for now playing app
- Music preview no longer requires automation permissions
- Xcode preview no longer requires automation permissions
- Hover view border matches mission control 
- Increased max preview size significantly
- Bug fixes

### 0.7.1

-   Privews are now displayed almost instantaneously (0.1 or less seconds even for large numbers of windows 20+)
-   Better handling of large number of windows
-   Sort preview windows by Desktop # then Window Title
-   Fix preview window flickering (redrawing) when moving mouse up from or down to a dock icon
-   Fix music view missalignment in window
-   Fix music view not updating if track rolls over while view is showing
-   Fix electron apps showing blank window if app is minimized 
    -   Instead shows last known image
    -   Image will still be blank if the window has not been unhidden since DockMate launched
-   Fix large preview window not hiding when last window of an app is closed
-   Fix windows potentially reporting the wrong space
-   Fix crash when web tab reported no title
-   Removed tab management from web views

### 0.6.1

-   Major code refactoring
-   Massive speed up of preview display time
-   Fixed memory leaks
-   Fix crash if music app was closed while displaying view
-   Chrome and Safari previews now show a tab selector

### 0.5.1

-   Fix memory leak
-   Fix tiles displaying off screen
-   Smaller minimum tile size

### 0.4.22

-    Progress bar works for iTunes, Spotify, Music apps
-    Track progress updates over time
-    Tiles showing when they shouldn't
-    Podcasts view progress-bar skip to point when clicked / dragged
-    Podcasts view progress-bar show progress while playing
-    Music views scrolling title and artist text
-    Setup Appcenter
-    Setup Paddle
-    Setup Sparkle
-    Setup LetsMove
-    Make about window
-    Space transitions
-    Fade in window
-    Window drawing over dock
-    Preview preference settings
-    Dock icon focus time before showing preview
-    Hover on preview to show floating "On-screen" preview
-    Finish General Preferences
-    Watch for dock restarts
-    Bug fixes
