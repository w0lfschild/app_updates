### Todo

-    Display windows for Screen-recording and Automation explaining the reasoning to the userbefore the system prompts

### 0.6.1

-   Major code refactoring
-   Massive speed up of preview display time
-   Fixed memory leaks
-   Fix crash if music app was closed while displaying view
-   Chrome and Safari previews now show a tab selector

### 0.5.1

-   Fix memory leak
-   Fix tiles displaying off screen
-   Smaller minimum tile size

### 0.4.22

-    Progress bar works for iTunes, Spotify, Music apps
-    Track progress updates over time
-    Tiles showing when they shouldn't
-    Podcasts view progress-bar skip to point when clicked / dragged
-    Podcasts view progress-bar show progress while playing
-    Music views scrolling title and artist text
-    Setup Appcenter
-    Setup Paddle
-    Setup Sparkle
-    Setup LetsMove
-    Make about window
-    Space transitions
-    Fade in window
-    Window drawing over dock
-    Preview preference settings
-    Dock icon focus time before showing preview
-    Hover on preview to show floating "On-screen" preview
-    Finish General Preferences
-    Watch for dock restarts
-    Bug fixes
