## Troubleshooting 🐛

- Having problems? Submit an issue here: [submit](https://github.com/w0lfschild/MacForge/issues/new/choose)
