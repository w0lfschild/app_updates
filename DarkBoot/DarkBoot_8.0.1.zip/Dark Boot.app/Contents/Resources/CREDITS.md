### Resources

- Original source : [bootxchanger](https://github.com/zydeco/bootxchanger)
- Boot Coloring : [DarkBoot-NVRAM](https://github.com/dabrain13/DarkBoot-NVRAM)
- Analytics : [appcenter-sdk-apple](https://www.github.com/microsoft/appcenter-sdk-apple)
- Updates : [Sparkle](https://www.github.com/sparkle-project/Sparkle)
- Auto move : [LetsMove](https://www.github.com/potionfactory/LetsMove)
- Privledged scripts : [STPrivilegedTask](https://www.github.com/sveinbjornt/STPrivilegedTask)

### Lead Developer

- [Wolfgang Baird](https://github.com/w0lfschild) ([w0lfschild](https://github.com/w0lfschild)) ([MacEnhance](https://www.macenhance.com/))

### Contributors

- [Contribute](https://github.com/w0lfschild/DarkBoot)
