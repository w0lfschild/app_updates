### Todo

-    Display windows for Screen-recording and Automation before the system prompts
-    Faster preview window load

### 0.5.1

-   Fix memory leak
-   Fix tiles displaying off screen
-   Smaller minimum tile size

### 0.4.22

-    Progress bar works for iTunes, Spotify, Music apps
-    Track progress updates over time
-    Tiles showing when they shouldn't
-    Podcasts view progress-bar skip to point when clicked / dragged
-    Podcasts view progress-bar show progress while playing
-    Music views scrolling title and artist text
-    Setup Appcenter
-    Setup Paddle
-    Setup Sparkle
-    Setup LetsMove
-    Make about window
-    Space transitions
-    Fade in window
-    Window drawing over dock
-    Preview preference settings
-    Dock icon focus time before showing preview
-    Hover on preview to show floating "On-screen" preview
-    Finish General Preferences
-    Clean up icon
-    Watch for dock restarts? To recapture the Dock accessibility item
-    Bug fixes
